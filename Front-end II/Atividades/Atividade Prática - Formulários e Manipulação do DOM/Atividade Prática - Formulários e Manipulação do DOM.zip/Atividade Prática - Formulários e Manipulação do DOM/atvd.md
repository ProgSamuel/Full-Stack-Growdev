[ok] 1. Desenvolva uma página HTML que replique a imagem acima, contendo um formulário com todos os itens mostrados.

[ok] 2. Todos os campos de dados pessoais devem ser preenchidos obrigatoriamente pelo usuário.

[ok] 3. Ao carregar a página deve vir previamente marcado um dos radios buttons.

[ok] 4. O usuário deve marcar ao menos um checkbox. Deve ser validado o preenchimento desse input.

[ok] 5. O campo de texto de label “mini-curriculo” não é obrigatório o preenchimento pelo usuário.

[ ] 6. Capture os dados preenchidos no formulário utilizando os métodos de manipulação do DOM. Ao final, mostre no console.log os dados preenchidos pelo usuário.