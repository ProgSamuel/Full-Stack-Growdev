# APIListaDeRecados
Atividade de Avaliação Final - Módulo Back-end - GrowDev

Atividade proposta para a criação de uma API de Lista de Recados, com algumas funcionalidades:

- Criação de conta;
- Login;
- CRUD* de recados.

<img src="https://github.com/mr-ricardoberti/APIListaDeRecados/blob/main/images/criaUsuario.PNG" alt="Criação do Usuário">
<img src="https://github.com/mr-ricardoberti/APIListaDeRecados/blob/main/images/loginUsuario.PNG" alt="Login do Usuário">
<img src="https://github.com/mr-ricardoberti/APIListaDeRecados/blob/main/images/leUsuario.PNG" alt="Leitura do Usuário">
<img src="https://github.com/mr-ricardoberti/APIListaDeRecados/blob/main/images/criarRecado.PNG" alt="Criação do Recado">
<img src="https://github.com/mr-ricardoberti/APIListaDeRecados/blob/main/images/leRecado.PNG" alt="Leitura do Recado">
<img src="https://github.com/mr-ricardoberti/APIListaDeRecados/blob/main/images/leRecadoPorId.PNG" alt="Leitura do Recado por ID">
<img src="https://github.com/mr-ricardoberti/APIListaDeRecados/blob/main/images/editaRecado.PNG" alt="Edição do Recado">
<img src="https://github.com/mr-ricardoberti/APIListaDeRecados/blob/main/images/deletaRecado.PNG" alt="Exclusão do Recado">

Espero que gostem!
