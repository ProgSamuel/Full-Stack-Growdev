[] imagem olho sumindo
[] porta aparece
[] titulo aparece aos pouxcos
video aparece - msm animation do tituilo ou um pouco depois 

data de lançamento  - botoes ou botao