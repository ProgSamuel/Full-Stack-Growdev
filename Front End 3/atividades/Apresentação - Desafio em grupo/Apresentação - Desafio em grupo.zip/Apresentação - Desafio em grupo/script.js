window.sr = ScrollReveal({reset: true});

sr.reveal('#home', {duration: 1000})

sr.reveal('#descricao', {
    duration: 1000
})

sr.reveal('#elenco', {
    duration: 1000
})